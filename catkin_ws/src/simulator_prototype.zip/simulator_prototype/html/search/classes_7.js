var searchData=
[
  ['weather',['Weather',['../class_weather.html',1,'']]]
];
