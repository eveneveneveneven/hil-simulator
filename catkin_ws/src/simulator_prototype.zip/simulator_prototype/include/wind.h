#ifndef WIND_H
#define WIND_H

#include "weather.h"

class Wind : public weather {

}

#endif